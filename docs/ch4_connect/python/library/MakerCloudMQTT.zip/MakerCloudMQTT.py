# !/usr/bin/python 3
# encoding: utf-8
import paho.mqtt.client as mqtt
import threading

__broker = 'mqtt.makercloud.scaleinnotech.com'
__port = 1883

dsn = 'python_'
dn = 'python_'
username = ""

coordinate_handler = None
key_message_handler = None
key_value_handler = None
message_handler = None

pending_subscribe_list = []
subscribed_topics = []

printLog = False

def on_connect(client, userdata, flags, rc):
	global pending_subscribe_list

	for topic in pending_subscribe_list:
		try:
			if topic not in subscribed_topics:
				client.subscribe(topic)
				subscribed_topics.append(topic)
				if printLog:
					print('connected to topic : {topic}'.format(topic=topic))
			else:
				if printLog:
					print('duplicate subscribe! {topic}'.format(topic=topic))
		except:
			print('failed to connect to topic: {topic}'.format(topic=topic))
		finally:
			pending_subscribe_list = []


def on_message(client, userdata, msg):
	parse_mc_message(msg.topic, msg.payload.decode('utf-8'))


def subscribe(topics):
	global pending_subscribe_list

	client = mqtt.Client()
	pending_subscribe_list = topics.split(',')
	client.on_connect = on_connect
	client.on_message = on_message
	client.connect(__broker, __port)

	threading.Thread(target=start_subscribe, args=(client,), name='subscribe_thread').start()


def start_subscribe(client):
	client.loop_forever()


def __publish(topic, content):
	client = mqtt.Client()
	client.connect(__broker, __port, 60)
	client.publish(topic, content)
	if printLog:
		print('[PUBLISH] publish message:{content} to topic:{topic}'.format(content=content, topic=topic))


def publish_coordination(topic, latitude, longitude):
	if isinstance(latitude, float) and isinstance(longitude, float):
		content = '_dsn={dsn},_dn={dn},lat={lat},lng={lng}'.format(dsn=dsn+str(username), dn=dn+str(username), lat=str(latitude), lng=str(longitude))
		__publish(topic, content)
	else:
		print('invalid input type(float required)' + "latitude: " + str(latitude) + "," + "longitude: " + str(longitude))


def publish_key_message(topic, key, message):
	content = '_dsn={dsn},_dn={dn},{key}={message}'.format(dsn=dsn + str(username), dn=dn + str(username), key=str(key), message=str(message))
	__publish(topic, content)


def publish_key_value(topic, key, value):
	if isinstance(value, float) or isinstance(value, int):
		content = '_dsn={dsn},_dn={dn},{key}={value}'.format(dsn=dsn + str(username), dn=dn + str(username), key=str(key), value=str(value))
		__publish(topic, content)
	else:
		print('invalid input type(float / int required)' + 'value: ' + str(value))


def publish_message(topic, message):
	content = '_dsn={dsn},_dn={dn},{message}'.format(dsn=dsn + str(username), dn=dn + str(username), message=str(message))
	__publish(topic, content)


def parse_mc_message(topic, content):
	message_map = {}

	for item in content.split(','):
		split_message = item.split("=")

		if len(split_message) == 1:
			message_map[None] = item
		elif split_message[0] != '_dsn' and split_message[0] != '_dn':
			message_map[split_message[0]] = split_message[1]

	if 'lat' in message_map and 'lng' in message_map:
		if coordinate_handler is not None:
			coordinate_handler(topic, message_map['lat'], message_map['lng'])
		else:
			print('Please define coordinate_handler!')
			default_message_handler(topic, content)
	elif None in message_map:
		if message_handler is not None:
			message_handler(topic, message_map[None])
		else:
			print('Please define message_handler!')
			default_message_handler(topic, content)
	else:
		key = next(iter(message_map))
		value = next(iter(message_map.values()))
		message_type = ''

		try:
			float(value)
			message_type = 'float'
		except:
			message_type = 'string'

		if message_type == "float" and key_value_handler is not None:
			key_value_handler(topic, key, value)
		elif key_message_handler is not None:
			key_message_handler(topic, key, value)
		else:
			print('Please define key_value_handler or key_message_handler!')
			default_message_handler(topic, content)


def default_message_handler(topic, message):
	if printLog:
		print('[{topic}] {message}'.format(topic=topic, message=message))

